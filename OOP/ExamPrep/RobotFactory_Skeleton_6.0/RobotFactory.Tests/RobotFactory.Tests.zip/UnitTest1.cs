using NUnit.Framework;
using RobotFactory;

namespace RobotFactory.Tests
{
    [TestFixture]
    public class SupplementTests
    {
        [Test]
        public void ToStringReturnsCorrectFormat()
        {
            // Arrange
            string name = "TestSupplement";
            int interfaceStandard = 42;
            Supplement supplement = new Supplement(name, interfaceStandard);

            // Act
            string result = supplement.ToString();

            // Assert
            string expected = $"Supplement: {name} IS: {interfaceStandard}";
            Assert.AreEqual(expected, result);
        }

        [Test]
        public void NameGetterSetterWorkingCorrectly()
        {
            // Arrange
            string name = "TestSupplement";
            Supplement supplement = new Supplement("InitialName", 1);

            // Act
            supplement.Name = name;

            // Assert
            Assert.AreEqual(name, supplement.Name);
        }

        [Test]
        public void InterfaceStandardGetterSetterWorkingCorrectly()
        {
            // Arrange
            int interfaceStandard = 42;
            Supplement supplement = new Supplement("TestSupplement", 1);

            // Act
            supplement.InterfaceStandard = interfaceStandard;

            // Assert
            Assert.AreEqual(interfaceStandard, supplement.InterfaceStandard);
        }
        [Test]
        public void ToStringReturnsCorrectFormat2()
        {
            // Arrange
            string model = "TestModel";
            double price = 999.99;
            int interfaceStandard = 42;
            Robot robot = new Robot(model, price, interfaceStandard);

            // Act
            string result = robot.ToString();

            // Assert
            string expected = $"Robot model: {model} IS: {interfaceStandard}, Price: {price:f2}";
            Assert.AreEqual(expected, result);
        }

        [Test]
        public void SupplementsAddSupplementSupplementListContainsNewSupplement()
        {
            // Arrange
            Robot robot = new Robot("TestModel", 999.99, 42);
            Supplement supplement = new Supplement("TestSupplement", 1);

            // Act
            robot.Supplements.Add(supplement);

            // Assert
            Assert.Contains(supplement, robot.Supplements);
        }

        [Test]
        public void PriceGetterSetterWorkingCorrectly()
        {
            // Arrange
            double price = 999.99;
            Robot robot = new Robot("TestModel", 1.0, 42);

            // Act
            robot.Price = price;

            // Assert
            Assert.AreEqual(price, robot.Price);
        }

        [Test]
        public void ModelGetterSetterWorkingCorrectly()
        {
            // Arrange
            string model = "TestModel";
            Robot robot = new Robot("InitialModel", 1.0, 42);

            // Act
            robot.Model = model;

            // Assert
            Assert.AreEqual(model, robot.Model);
        }

        [Test]
        public void InterfaceStandardGetterSetterWorkingCorrectly2()
        {
            // Arrange
            int interfaceStandard = 42;
            Robot robot = new Robot("TestModel", 1.0, 1);

            // Act
            robot.InterfaceStandard = interfaceStandard;

            // Assert
            Assert.AreEqual(interfaceStandard, robot.InterfaceStandard);
        }
    }
}

