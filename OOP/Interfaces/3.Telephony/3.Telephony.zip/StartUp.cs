﻿using _3.Telephony.Models;
using _3.Telephony.Models.Interfaces;

namespace _3.Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {


            string[] phoneNumbers = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries);
            string[] urls = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries);


            ICallable phone;
            foreach (var item in phoneNumbers)
            {
                if (item.Length == 10)
                {
                    phone = new Smartphone();
                }
                else
                {
                    phone = new StationaryPhone();

                }

                try
                {
                    Console.WriteLine(phone.Call(item));

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

            IBrowsable browsable = new Smartphone();

            foreach (var item in urls)
            {
                try
                {
                    Console.WriteLine(browsable.Browse(item));


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}