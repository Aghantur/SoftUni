﻿using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace ShoeStore
{
    public class ShoeStore
    {

        public string Name { get; }
        public int StorageCapacity { get; }
        private List<Shoe> Shoes { get; }

        public int Count => Shoes.Count;

        public ShoeStore(string name, int storageCapacity)
        {
            Name = name;
            StorageCapacity = storageCapacity;
            Shoes = new List<Shoe>();
        }

        public string AddShoe(Shoe shoe)
        {
            if (Count >= StorageCapacity)
            {
                return "No more space in the storage room.";
            }

            Shoes.Add(shoe);
            return $"Successfully added {shoe.Type} {shoe.Material} pair of shoes to the store.";
        }

        public int RemoveShoes(string material)
        {
            int removedCount = Shoes.RemoveAll(shoe => shoe.Material.Equals(material, StringComparison.OrdinalIgnoreCase));
            return removedCount;
        }

        public List<Shoe> GetShoesByType(string type)
        {
            List<Shoe> matchingShoes = Shoes.FindAll(shoe => shoe.Type.Equals(type, StringComparison.OrdinalIgnoreCase));
            return matchingShoes;
        }

        public Shoe GetShoeBySize(double size)
        {
            Shoe shoe = Shoes.Find(sh => Math.Abs(sh.Size - size) < double.Epsilon);
            return shoe;
        }

        public string StockList(double size, string type)
        {
            List<Shoe> matchingShoes = Shoes.FindAll(shoe =>
                shoe.Size == size &&
                shoe.Type.Equals(type, StringComparison.OrdinalIgnoreCase));

            if (matchingShoes.Count > 0)
            {
                string stockList = $"Stock list for size {size} - {type} shoes:\n";
                stockList += string.Join("\n", matchingShoes);
                return stockList;
            }
            else
            {
                return "No matches found!";
            }
        }
    }
}

